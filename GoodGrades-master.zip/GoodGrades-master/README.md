# Good Grades   [![CircleCI](https://circleci.com/gh/rde-kwaa/GoodGrades/tree/master.svg?style=svg&circle-token=89cb641d483622d9806976e3ad3095d55aa1d800)](https://circleci.com/gh/rde-kwaa/GoodGrades/tree/master)

  Good Grades is a communications platform for students to connect to tutors and receive assistance with problematic subject  matter.

  Students can book available tutors for both remote and face-to-face sessions.

  Students are able to contact a tutor for immediate assitance when they need it.

## Available Scripts

In the project directory, you can run:

### `npm run dev`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `npm start`

Builds the app for production to the `build` folder.<br />
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br />
Your app is ready to be deployed!
