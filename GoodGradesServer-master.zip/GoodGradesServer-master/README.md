# GoodGradesServer [![CircleCI](https://circleci.com/gh/jde-agr/GoodGradesServer.svg?style=svg&circle-token=0113522473b900736259cb957f95adbdff9c02c7)](https://circleci.com/gh/jde-agr/GoodGradesServer)

## Summary

The server for Good Grades which currently manages server side api calls that are used by the client.