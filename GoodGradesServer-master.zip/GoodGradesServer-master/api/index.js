module.exports = {
    room: require('./room'),
    user: require('./user'),
    event: require('./event'),
    quickHelp: require('./quickHelp')
}